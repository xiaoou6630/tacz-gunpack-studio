# TACZ 枪包工坊 · TaCZ Gun Studio

> 一个仓库，两半插件：**美术在 Blockbench，数据在 DeepSeek Harness**。
> 用 AI 从零做出一把能被 TaCZ（永恒枪械工坊：零）加载的枪，并导出可校验的枪包。

[![License: MIT](https://img.shields.io/badge/dsh--plugin-MIT-blue.svg)](LICENSES/MIT.txt)
[![License: GPL v3](https://img.shields.io/badge/blockbench--plugin-GPL--3.0-red.svg)](LICENSES/GPL-3.0.txt)

---

## 这是什么

TaCZ 枪包 = 模型 + 贴图 + 图标 + 一堆 JSON。手工做一遍要反复对路径、对字段、对组名，很容易错在细节上。

本项目把它拆成两半，各管各的，互不覆盖：

| 半边 | 装在哪 | 管什么 | 许可 |
|---|---|---|---|
| **美术侧** | Blockbench | 几何、UV 图集、贴图、slot/HUD 图标、`.bbmodel` | GPL-3.0-only |
| **数据侧** | DeepSeek Harness | index/data/display/lang、配方、标签、构建控制器、六个角色 | MIT |

核心约束：**美术侧永不写数据，数据侧永不建模。** 两边靠本地 HTTP MCP 端点通信，不共享文件所有权，所以不会互相踩。

---

## 功能

### 数据侧（DeepSeek Harness 插件）

- **六个角色**：总监 + 建模 / 数据 / 审核 / 搜索 / 学习，每个角色有独立的可改写 `SKILL.md`
- **构建控制器** `tacz_build`：`INIT → RESEARCH → BLUEPRINT → GEOMETRY → DATA → REVIEW → PACKAGE → READY → DONE`，卡阶段、卡产物、卡人工验收
- **弹药与配件数据** `tacz_item`：index / display / data / lang / 配方 / `allow_attachments` 标签，一次写全
- **交叉校验** `tacz_verify`：把 display 里的每个引用都对着磁盘查一遍
- **官方基准** `tacz_spec`：优先本地，缺了从 `MCModderAnchor/TACZ@1.20.1` 取
- **自学习** `tacz_skill`：从审核缺陷提炼经验，改写技能，带版本可回滚

### 美术侧（Blockbench MCP 插件）

- `tacz_pack` / `tacz_gun`：建包、建枪、导出几何与 UV
- `tacz_ammo` / `tacz_attachment`：弹药和配件的模型、UV、图标
- `tacz_icon_render`：slot（等轴右视角、关阴影、枪口朝右、64×64）与 HUD（侧视、关阴影、枪口朝左、384×128）
- `tacz_model_validate`：组名、骨骼、UV、贴图尺寸自检

---

## 安装

### 前置要求

- **Blockbench 5.0 或更新**（桌面版）
- **DeepSeek Harness 0.2.1-rc.5 ~ 0.2.x**
- **Node.js 20+**

### 第一步：装 Blockbench 插件

从 [Releases](https://github.com/xiaoou6630/tacz-gunpack-studio/releases) 下载 `mcp.js`，放进 Blockbench 的插件目录：

| 系统 | 路径 |
|---|---|
| Windows | `%APPDATA%\Blockbench\plugins\mcp.js` |
| macOS | `~/Library/Application Support/Blockbench/plugins/mcp.js` |
| Linux | `~/.config/Blockbench/plugins/mcp.js` |

然后**重启 Blockbench**（或 Plugins → Reload plugins）。

打开 **Settings → General** 确认 MCP 服务器已启用，默认端点 `http://127.0.0.1:3000/bb-mcp`。

> **必须重启。** 已经运行的 Blockbench 会把旧版本留在内存里，新参数会被静默忽略。

### 第二步：装 DeepSeek Harness 插件

**方式 A：从 GitHub 直接装（推荐，一条命令）**

```sh
dsh plugin --profile desktop add github:xiaoou6630/tacz-gunpack-studio#v0.1.0
```

**方式 B：装指定子包**

```sh
dsh plugin --profile desktop add github:xiaoou6630/tacz-gunpack-studio#v0.1.0:packages/dsh-tacz-gunpack
```

**方式 C：从 Release 里的 tgz**

```sh
dsh plugin --profile desktop add ./dsh-tacz-gunpack-0.1.0.tgz
```

装完**重启 DSH**。插件会注册 `tacz-gunpack` 预设（「TACZ 枪包工坊」），新建会话时选它。

### 第三步：把 Blockbench 接进 DSH

在 TACZ 会话里执行：

```
tacz_install_mcp
```

它会把 `mcp-blockbench` 这一行写进当前 profile 的 patch 文件，并先备份原文件。`mcp__blockbench__*` 工具会在新会话或 HMR 后出现。

---

## 验证装好了

在 TACZ 会话里依次跑：

| 命令 | 期望 |
|---|---|
| `tacz_status` | 列出六个角色、已装载技能、`blockbench_tool_count` 非 0 |
| `tacz_install_preset` | `registered: true` |
| `tacz_spec action="locate"` | 报告官方基准来源 |
| 直接说「做个霰弹枪」 | 总监**先反问**口径/型号/是否要动画，而不是闷头猜 |

---

## 怎么用

跟它说需求就行，例如：

```
给我做一把 KSG 泵动霰弹枪，12 号口径，14 发管式弹仓
```

总监会：

1. 问清缺的信息（型号细节、风格、是否需要动画）
2. 派 researcher 找参考图和真实参数，写设计 brief
3. 派 modeler 在 Blockbench 建骨骼、几何、UV、贴图、图标
4. 派 data-smith 写 index/data/display/lang、配方、配件标签
5. 派 reviewer 只读审核，blocker 清零
6. 校验、打包成 `output/<gun>.zip` 和 `models/<gun>.bbmodel`
7. **你进游戏实测**，通过了才 `tacz_build action="ack" confirmed=true`

阶段不能跳，`validation.ok=false` 不能打包，没有人工确认不能 `DONE`。

---

## 目录结构

```
tacz-gunpack-studio/
├─ packages/
│  ├─ blockbench-mcp-tacz/       美术侧（GPL-3.0-only）
│  └─ dsh-tacz-gunpack/          数据侧（MIT）
├─ docs/                          枪包格式规范（中文，已核对官方 wiki 与默认枪包）
├─ LICENSES/                      GPL-3.0 与 MIT 全文
├─ NOTICE.md                      两半的许可说明
└─ README.md
```

---

## 图标规格（官方口径）

| | 尺寸 | 视角 | 阴影 | 枪口朝向 |
|---|---|---|---|---|
| **slot** 槽位图 | 64×64 | 等轴视角右 | **关** | **朝右** |
| **HUD** 平面图 | 384×128（3:1） | 侧视 | **关** | **朝左** |

来源：官方 wiki `gun/display/03_hud`，并用官方默认枪包的 PNG 实测核对过颜色数与朝向。

> 注意：两张图都是**保留模型自身配色**的渲染，不是单色剪影。纯色是误读。

---

## 安全说明

- **`risky_eval` 默认关闭。** 它允许任何连上本地 MCP 端口的程序在 Blockbench 里执行任意 JavaScript。TACZ 工具链完全不需要它。如果你手动打开过，Blockbench 会记住旧值，需要手动关一次。
- 插件只连三个端点：`127.0.0.1:3000`（你本机的 Blockbench）、Bing Images（搜参考图，只发搜索词）、GitHub API（取官方基准文件，只发仓库路径）。
- **无遥测、无埋点、无远程执行。** 不上传工程数据。

---

## 常见问题

**Q：DSH 里看不到 `mcp__blockbench__*` 工具？**
先跑 `tacz_install_mcp`，再开新会话。确认 Blockbench 正在运行，且端口一致。

**Q：升级后行为没变？**
Blockbench 和 DSH 都各重启一次。两者都会把旧版本留在内存。

**Q：技能看起来还是旧的？**
DSH 插件加载时会按字节比对，自动刷新过期技能，旧版归档到 `<role>/versions/`。如果还不对，重启 DSH。

**Q：改枪界面里枪飞到天上？**
模型缺 `refit_*_view` 组。见 `docs/tacz-wiki-authority.md`。

**Q：配件装不上？**
需要三样同时存在：`allow_attachment_types`、`allow_attachments` 标签、模型里的 `*_pos` 定位组。

---

## 许可

本项目是**两半分开许可**的，详见 [NOTICE.md](NOTICE.md)。

- **`packages/blockbench-mcp-tacz/` — GPL-3.0-only。** 它是
  [jasonjgardner/blockbench-mcp-plugin](https://github.com/jasonjgardner/blockbench-mcp-plugin)
  的 fork，原作者 Jason J. Gardner。GPL 全文见 `LICENSES/GPL-3.0.txt`，改动清单与来源 commit 见
  `packages/blockbench-mcp-tacz/SOURCE.txt`。再分发这一半时，必须随附许可、提供对应源码、保持 GPL-3.0。
- **`packages/dsh-tacz-gunpack/` — MIT。** 原创，全文见 `LICENSES/MIT.txt`。
- **`docs/` — MIT。**

本项目**不包含**任何 TACZ 游戏资源、模型、贴图、音效或官方默认枪包。`tacz_spec` 只会在运行时从官方仓库取基准文件，缓存在本地，不随包分发。

---

## 致谢

- [TaCZ / Timeless and Classics Zero](https://github.com/MCModderAnchor/TACZ) — 模组本体与官方枪包规范
- [TaCZ Wiki](https://tacwiki.mcma.club/zh/gunpack) — 枪包格式文档，本项目规范的主要依据
- [jasonjgardner/blockbench-mcp-plugin](https://github.com/jasonjgardner/blockbench-mcp-plugin) — Blockbench MCP 插件上游
- [DeepSeek Harness](https://github.com/deepseek-ai) — Agent Teams 与插件运行时
